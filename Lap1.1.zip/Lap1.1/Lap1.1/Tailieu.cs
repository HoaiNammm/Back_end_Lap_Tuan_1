﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lap1._1
{
     class Tailieu
    {
        protected string? matl { get; set; }
        protected string? tnxb { get; set; }
        protected int soBan;

        public Tailieu() { }

        // Phương thức khởi tạo có tham số
        public Tailieu(string matl, string tnxb, int soBan) 
        { 
            this.matl = matl;
            this.tnxb = tnxb;  
            this.soBan = soBan;
        }

        //Nhập thông tin tài liệu
        public virtual void Nhap() {
            try
            {
                Console.WriteLine("+ Mã tài liệu: ");
                matl = Console.ReadLine();
                Console.WriteLine("+ Tên nhà xuat ban: ");
                tnxb = Console.ReadLine();
                Console.WriteLine("+ Số bản: ");
                soBan = int.Parse(Console.ReadLine());
            }
            catch (Exception ex)
            {
                
                throw new Exception(ex.Message);
            }
        }
        //Hiển thị thông tin tài liệu
        public virtual void Xuat()
        {
            Console.WriteLine($"Mã tài liệu: {matl}");
            Console.WriteLine( $"+ Tên nhà xb: {tnxb}");
            Console.WriteLine($"Số bản phát hành: {soBan}");
        }
    }
}

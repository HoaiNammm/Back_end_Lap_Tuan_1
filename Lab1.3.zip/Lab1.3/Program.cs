﻿using Lab1._3;

class QuanLyTaiLieu
{
    private List<TaiLieu> danhSachTaiLieu = new List<TaiLieu>();

    // Nhập thông tin tài liệu
    public void NhapThongTin()
    {
        Console.WriteLine("Chon loai tai lieu de nhap (1: Sach, 2: Tap chi, 3: Bao): ");
        string luaChon = Console.ReadLine();

        switch (luaChon)
        {
            case "1":
                Sach sach = new Sach();
                sach.Nhap();
                danhSachTaiLieu.Add(sach);
                break;
            case "2":
                TapChi tapChi = new TapChi();
                tapChi.Nhap();
                danhSachTaiLieu.Add(tapChi);
                break;
            case "3":
                Bao bao = new Bao();
                bao.Nhap();
                danhSachTaiLieu.Add(bao);
                break;
            default:
                Console.WriteLine("Lua chon khong hop le!");
                break;
        }
    }

    // Hiển thị thông tin tất cả tài liệu
    public void HienThiThongTin()
    {
        if (danhSachTaiLieu.Count == 0)
        {
            Console.WriteLine("Danh sach tai lieu trong!");
            return;
        }
        Console.WriteLine("\n=== DANH SACH TAI LIEU ===");
        foreach (var taiLieu in danhSachTaiLieu)
        {
            Console.WriteLine("-------------------");
            taiLieu.Xuat();
        }
    }

    // Tìm kiếm tài liệu theo loại
    public void TimKiemTheoLoai(string loai)
    {
        bool found = false;
        Console.WriteLine($"\n=== KET QUA TIM KIEM: {loai} ===");
        foreach (var taiLieu in danhSachTaiLieu)
        {
            if ((loai == "Sach" && taiLieu is Sach) ||
                (loai == "TapChi" && taiLieu is TapChi) ||
                (loai == "Bao" && taiLieu is Bao))
            {
                taiLieu.Xuat();
                Console.WriteLine("-------------------");
                found = true;
            }
        }
        if (!found)
            Console.WriteLine($"Khong tim thay tai lieu loai {loai}!");
    }

    // Chương trình chính
    static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyTaiLieu ql = new QuanLyTaiLieu();
        while (true)
        {
            Console.WriteLine("\n=== QUAN LY THU VIEN ===");
            Console.WriteLine("1. Nhap thong tin tai lieu");
            Console.WriteLine("2. Hien thi thong tin tai lieu");
            Console.WriteLine("3. Tim kiem tai lieu theo loai");
            Console.WriteLine("4. Thoat");
            Console.Write("Chon chuc nang: ");
            string chon = Console.ReadLine();

            try
            {
                switch (chon)
                {
                    case "1":
                        ql.NhapThongTin();
                        break;
                    case "2":
                        ql.HienThiThongTin();
                        break;
                    case "3":
                        Console.Write("Nhap loai tai lieu (Sach/TapChi/Bao): ");
                        string loai = Console.ReadLine();
                        ql.TimKiemTheoLoai(loai);
                        break;
                    case "4":
                        Console.WriteLine("Tam biet!");
                        return;
                    default:
                        Console.WriteLine("Chuc nang khong hop le!");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi: " + ex.Message);
            }
        }
    }
}
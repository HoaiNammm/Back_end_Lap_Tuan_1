﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1._3
{
    class Sach: TaiLieu
    {
        //Khai báo thuộc tính
        private string? tenTG;
        private int soTrang;
        //Phương thức khởi tạo mặc định
        public Sach() { }
        //Phương thức khởi tạo có tham số
        public Sach(string? maTL, string? tenNXB, int soBan, string? tenTG, int soTrang) : base()
        {
            this.tenTG = tenTG;
            this.soTrang = soTrang;
        }
        // phương thức nhập thông tin sách
        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.Write("+ Ten tac gia: ");
                tenTG = Console.ReadLine();
                Console.Write("+ So trang: ");
                soTrang = int.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        // phương thức hiển thị
        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"+ Ten tac gia: {tenTG}");
            Console.WriteLine($"+ So trang: {soTrang}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lap1._1
{
    internal class Sach: Tailieu
    {
        //Khai báo thuộc tính
        private string tentg;
        private int sotrang;
        public Sach() { }
        public Sach(string matl, string tnxb, int soBan ,string tentg, int sotrang):base
            (matl, tnxb, soBan)
        {
            this.tentg = tentg;
            this.sotrang = sotrang;
        }

        // phương thức nhập thông tin sách
        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.WriteLine("+ Tên tác giả: ");
                tentg = Console.ReadLine();
                Console.WriteLine("+ Số trang: ");
                sotrang = int.Parse(Console.ReadLine());
            }
            catch (Exception ex)
            {

                throw new Exception (ex.Message);
            }
            
        }

        public override void Xuat()
        {
            base.Xuat();
            Console.WriteLine($"Tên tác giả: {tentg}");
            Console.WriteLine($"Số trang: {sotrang}");
        }
    }
}

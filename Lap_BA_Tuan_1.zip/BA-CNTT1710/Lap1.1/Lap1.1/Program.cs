﻿//Console.WriteLine("Hello, World!");
//Bài 1: Viết chương trình nhập vào tên, tuổi
using System;
using System.Security.Cryptography;

Console.OutputEncoding = System.Text.Encoding.UTF8;
//string? ten;
//int tuoi;
//// Nhập dữ liệu từ bàn phím
//Console.WriteLine("Nhập tên: ");
//ten = Console.ReadLine();
//Console.WriteLine("Nhập tuổi: ");
//tuoi = int.Parse(Console.ReadLine() ?? "0");

//// xuất ra màn hình
//Console.WriteLine($"Xin chào {ten}, bạn {tuoi} tuổi");

//Bài 2:  Viết chương trình tính diện tích của hình chữ nhật khi người dùng nhập chiều dài và chiều rộng.

//try
//{
//    double d, r, s;
//    Console.Write("Chiều dài: ");
//    d = double.Parse(Console.ReadLine() ?? "0");
//    Console.Write("Chiều rộng: ");
//    r = double.Parse(Console.ReadLine() ?? "0");
//    if (d <= 0 || r <= 0)
//        throw new Exception("Độ dài và rộng phải > 0");
//    s = d * r;
//    Console.WriteLine($"Diện tích {s}");

//}
//catch (FormatException ex)
//{
//    Console.WriteLine(" Bạn nhập sai r: "+ ex.Message);
//        ;
//}

//catch (Exception ex )
//{ Console.WriteLine("Lỗi: " + ex.Message);
//}

//Bài 3: Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ Fa

//int C, F;
//Console.WriteLine("Nhập độ C: ");
//C = int.Parse(Console.ReadLine() ?? "0");
//F = (C * 9 / 5) + 32;
//Console.WriteLine($" {C} độ C được chuyển sang độ F là: {F} ");
/*
 * Bài 4:  Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn
hay không.

 int n;
Console.WriteLine("Nhập số: ");
n = int.Parse(Console.ReadLine() ?? "0");
if (n % 2 ==0)
{
    Console.WriteLine(" à số chẵn");
}

else
{
    Console.WriteLine("Là số lẻ");
}
 */

// Bài 5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím

/*
 int a, b, t;
Console.WriteLine("Nhap so a: ");
a = int.Parse(Console.ReadLine() ?? "0");
Console.WriteLine("Nhap so b: ");
b = int.Parse(Console.ReadLine() ?? "0");
t = a + b;
Console.WriteLine($"Tong cua 2 so la: {t}");
*/

// Bai 6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.

/*
 int n;
Console.WriteLine("Nhap so: ");
n = int.Parse(Console.ReadLine() ?? "0");
if (n < 0)
{
    Console.WriteLine("Day la so am");
    
}
else if (n > 0)
{
    Console.WriteLine($"Day la so duong");
}
else
{
    Console.WriteLine("Day la so 0");
}
*/

//Bài 7: 
int nam;
Console.WriteLine("Nhập năm: ");
nam = int.Parse(Console.ReadLine() ?? "0");
if (nam % 4 == 0) 
{
    if (nam % 100 == 0) 
    {
        if (nam % 400 == 0) 
        {
            Console.WriteLine("Là năm nhuận");
        }
    }
    else
    {
        Console.WriteLine("Không phải là năm nhuận");
    }
}




